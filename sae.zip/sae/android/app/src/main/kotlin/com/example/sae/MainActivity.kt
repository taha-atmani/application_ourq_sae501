package com.example.sae

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
