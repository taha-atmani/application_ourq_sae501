import 'package:flutter/material.dart';
// Importation de la bibliothèque Flutter pour utiliser les widgets Material Design.

import 'package:sae/screens/intro/scan_page.dart';
// Importation d'un écran personnalisé (ScanPage), présent dans ton projet.

void main() {
  runApp(const MyApp());
  // Point d'entrée de l'application : lance le widget MyApp.
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // Widget racine de l'application, sans état (Stateless).

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo', // Titre de l'application.
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        // Thème principal généré à partir d'une couleur de base.
        useMaterial3: true, // Utilisation des composants Material 3.
      ),
      home: ScanPage(), // Page affichée au lancement de l'application.
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  // Widget avec état, prenant un titre en paramètre.

  final String title; // Titre qui sera affiché dans la barre d'app.

  @override
  State<MyHomePage> createState() => _MyHomePageState();
  // Création de l'état associé à ce widget.
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0; // Variable d'état pour compter les clics sur le bouton.

  void _incrementCounter() {
    setState(() {
      _counter++;
      // Incrémente le compteur et met à jour l'interface.
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Scaffold structure la page (app bar, body, bouton flottant, etc.).
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        // Couleur de fond de la barre d'app selon le thème.
        title: Text(widget.title), // Affiche le titre dans la barre d'app.
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          // Centre verticalement les éléments.
          children: <Widget>[
            const Text(
              'You have pushed the button this many times:',
              // Texte fixe explicatif.
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headlineMedium,
              // Affiche la valeur du compteur avec un style de titre.
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        // Appelle la fonction pour incrémenter le compteur.
        tooltip: 'Increment', // Texte affiché au survol (desktop).
        child: const Icon(Icons.add), // Icône "+" dans le bouton.
      ), // Virgule à la fin pour faciliter le formatage automatique.
    );
  }
}
