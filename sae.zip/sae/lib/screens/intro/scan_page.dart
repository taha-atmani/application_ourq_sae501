import 'package:flutter/material.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';

import 'location_page.dart';

class ScanPage extends StatelessWidget {
  const ScanPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            StepProgressIndicator(
              totalSteps: 3,
              currentStep: 0,
              unselectedColor: Colors.grey,
            ),
            Spacer(),
            Image.asset("assets/scan_2 1.png"),
            Spacer(),
            Text(
              "Explore les lieux culturels grâce la carte interactive",
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  fontFamily: "libre"),
            ),
            const SizedBox(height: 20),
            Text(
              "Utilise la map et amuses toi avec des mini jeux en temps réel",
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                  color: Colors.black54,
                  fontFamily: "libre"),
            ),
            const SizedBox(height: 20),
            MaterialButton(
                minWidth: double.infinity,
                color: Color(0xFFDA494F),
                height: 64,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return LocationPage();
                  }));
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Suivant",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontFamily: "libre",
                          fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                    )
                  ],
                ))
          ],
        ),
      )),
    );
  }
}
