import 'package:flutter/material.dart'; // Importe les widgets et outils de base Flutter
import 'package:step_progress_indicator/step_progress_indicator.dart'; // Importe le widget de barre de progression

import 'location_page.dart'; // Importe la page suivante (LocationPage)

class ScanPage extends StatelessWidget {
  const ScanPage({super.key}); // Constructeur de la page ScanPage (stateless)

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        // Empêche le contenu d'empiéter sur les zones non interactives (notch, etc.)
        child: Padding(
          padding: const EdgeInsets.all(15.0), // Ajoute un padding tout autour
          child: Column(
            mainAxisAlignment: MainAxisAlignment
                .center, // Centre verticalement tous les enfants
            children: [
              StepProgressIndicator(
                // Indicateur de progression en haut
                totalSteps: 3, // Nombre total d'étapes
                currentStep: 0, // Étape actuelle
                unselectedColor:
                    Colors.grey, // Couleur des étapes non atteintes
              ),
              Spacer(), // Espace flexible pour centrer l'image
              Image.asset("assets/scan_2 1.png"), // Image d'illustration
              Spacer(), // Espace flexible pour centrer le texte
              Text(
                "Explore les lieux culturels grâce la carte interactive", // Titre principal
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: Colors.black,
                    fontFamily: "libre"),
              ),
              const SizedBox(height: 20), // Espace vertical entre les textes
              Text(
                "Utilise la map et amuses toi avec des mini jeux en temps réel", // Sous-texte
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                    color: Colors.black54,
                    fontFamily: "libre"),
              ),
              const SizedBox(height: 20), // Espace avant le bouton
              MaterialButton(
                minWidth: double.infinity, // Largeur maximale possible
                color: Color(0xFFDA494F), // Couleur du bouton (rouge)
                height: 64, // Hauteur du bouton
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10), // Bords arrondis
                ),
                onPressed: () {
                  // Lorsqu'on clique, on va vers la page LocationPage
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return LocationPage();
                  }));
                },
                child: Row(
                  // Contenu du bouton
                  mainAxisAlignment:
                      MainAxisAlignment.center, // Centre le texte et l'icône
                  children: [
                    Text(
                      "Suivant", // Texte dans le bouton
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontFamily: "libre",
                          fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(
                        width: 5), // Espace entre le texte et l'icône
                    Icon(
                      Icons.arrow_forward, // Icône flèche vers la droite
                      color: Colors.white,
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
