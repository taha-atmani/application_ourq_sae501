import 'package:flutter/material.dart'; // Importe les composants UI de Flutter
import 'package:geolocator/geolocator.dart'; // Permet d'accéder aux fonctionnalités de géolocalisation
import 'package:sae/screens/intro/select_page.dart'; // Importe la page suivante : SelectPage
import 'package:step_progress_indicator/step_progress_indicator.dart'; // Importe le widget d'indicateur de progression

class LocationPage extends StatelessWidget {
  const LocationPage({super.key}); // Constructeur de la page (stateless)

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        // Permet d'éviter les zones système (encoches, status bar...)
        child: Padding(
          padding: const EdgeInsets.all(15.0), // Padding autour du contenu
          child: Column(
            mainAxisAlignment:
                MainAxisAlignment.center, // Centre les éléments verticalement
            children: [
              StepProgressIndicator(
                // Barre de progression
                totalSteps: 3, // Nombre total d'étapes
                currentStep: 1, // Étape actuelle (2e)
                selectedColor:
                    Color(0xFFDA494F), // Couleur de l'étape sélectionnée
                unselectedColor: Colors.grey, // Couleur des autres étapes
              ),
              Spacer(), // Espace flexible pour centrer
              Image.asset(
                  "assets/pin map.png"), // Image illustrative (une carte avec un pin)
              Spacer(), // Espace flexible pour centrer
              Text(
                "Débloques des récompenses en scannant des QR code", // Titre principal
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  fontFamily: "libre",
                ),
              ),
              const SizedBox(height: 20), // Espace entre les textes
              Text(
                "Déplaces toi sur tes lieux favoris et profites de réductions exclusives en scannant des QR codes cachés", // Sous-texte explicatif
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                  color: Colors.black54,
                  fontFamily: "libre",
                ),
              ),
              const SizedBox(height: 20), // Espace avant le bouton
              MaterialButton(
                minWidth: double.infinity, // Bouton prend toute la largeur
                color: Color(0xFFDA494F), // Couleur de fond du bouton
                height: 64, // Hauteur du bouton
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10), // Coins arrondis
                ),
                onPressed: () async {
                  // Lors du clic, vérifie si la localisation est activée
                  bool serviceEnabled = await Geolocator.checkPermission() ==
                          LocationPermission.always ||
                      await Geolocator.checkPermission() ==
                          LocationPermission.whileInUse;

                  // Si ce n'est pas le cas, on demande la permission
                  if (!serviceEnabled) {
                    await Geolocator.requestPermission(); // Demande l'accès
                    serviceEnabled = await Geolocator
                        .isLocationServiceEnabled(); // Vérifie si c’est activé
                  }

                  // Si toujours pas activé, on affiche un message d'erreur
                  if (!serviceEnabled) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text(
                          "Veuillez activer la localisation"), // Message d'erreur
                      duration: Duration(seconds: 2), // Affiché pendant 2 sec
                    ));
                    return; // On arrête ici
                  } else {
                    // Si la localisation est OK, on passe à la page suivante
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return SelectPage(); // Redirection vers SelectPage
                    }));
                  }
                },
                child: Row(
                  mainAxisAlignment:
                      MainAxisAlignment.center, // Centre contenu du bouton
                  children: [
                    Text(
                      "Suivant", // Texte dans le bouton
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontFamily: "libre",
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 5), // Espace entre texte et icône
                    Icon(
                      Icons.arrow_forward, // Icône flèche vers la droite
                      color: Colors.white,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
