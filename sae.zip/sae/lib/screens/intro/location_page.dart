import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:sae/screens/intro/select_page.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';

class LocationPage extends StatelessWidget {
  const LocationPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            StepProgressIndicator(
              totalSteps: 3,
              currentStep: 1,
              selectedColor: Color(0xFFDA494F),
              unselectedColor: Colors.grey,
            ),
            Spacer(),
            Image.asset("assets/pin map.png"),
            Spacer(),
            Text(
              "Débloques des récompenses en scannant des QR code",
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  fontFamily: "libre"),
            ),
            const SizedBox(height: 20),
            Text(
              "Déplaces toi sur tes lieux favoris et profites de réductions exclusives en scannant des QR codes cachés",
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                  color: Colors.black54,
                  fontFamily: "libre"),
            ),
            const SizedBox(height: 20),
            MaterialButton(
                minWidth: double.infinity,
                color: Color(0xFFDA494F),
                height: 64,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                onPressed: () async {
                  bool serviceEnabled = await Geolocator.checkPermission() ==
                          LocationPermission.always ||
                      await Geolocator.checkPermission() ==
                          LocationPermission.whileInUse;
                  if (!serviceEnabled) {
                    await Geolocator.requestPermission();
                    serviceEnabled =
                        await Geolocator.isLocationServiceEnabled();
                  }
                  if (!serviceEnabled) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text("Veuillez activer la localisation"),
                      duration: Duration(seconds: 2),
                    ));
                    return;
                  } else {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return SelectPage();
                    }));
                  }
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Suivant",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontFamily: "libre",
                          fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                    )
                  ],
                ))
          ],
        ),
      )),
    );
  }
}
