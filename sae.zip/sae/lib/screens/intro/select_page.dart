import 'package:flutter/material.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';

import '../bottom_bar/bottom_nav.dart';

class SelectPage extends StatefulWidget {
  const SelectPage({super.key});

  @override
  State<SelectPage> createState() => _SelectPageState();
}

class _SelectPageState extends State<SelectPage> {
  List<String> selected = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            StepProgressIndicator(
              totalSteps: 3,
              currentStep: 2,
              selectedColor: Color(0xFFDA494F),
              unselectedColor: Colors.grey,
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              "Choisissez 2 ou 3 types de sorties qui vous intéressent. ",
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  fontFamily: "libre"),
            ),
            const SizedBox(
              height: 20,
            ),
            Expanded(
              child: GridView(
                  shrinkWrap: true,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    mainAxisExtent: 150,
                  ),
                  children: [
                    GestureDetector(
                      onTap: () {
                        if (selected.contains("Bars")) {
                          selected.remove("Bars");
                        } else if (selected.length < 3) {
                          selected.add("Bars");
                        }
                        setState(() {});
                      },
                      child: Stack(
                        children: [
                          Column(children: [
                            Image.asset("assets/beer.png"),
                            Text(
                              "Bars",
                              style: TextStyle(fontFamily: "libre"),
                            )
                          ]),
                          if (selected.contains("Bars"))
                            Positioned(
                              right: 5,
                              bottom: 40,
                              child: Icon(
                                Icons.check_circle,
                                size: 35,
                                color: const Color.fromARGB(255, 12, 68, 13),
                              ),
                            )
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        if (selected.contains("Cinemas")) {
                          selected.remove("Cinemas");
                        } else if (selected.length < 3) {
                          selected.add("Cinemas");
                        }
                        setState(() {});
                      },
                      child: Stack(
                        children: [
                          Column(children: [
                            Image.asset("assets/movie.png"),
                            Text(
                              "Cinemas",
                              style: TextStyle(fontFamily: "libre"),
                            )
                          ]),
                          if (selected.contains("Cinemas"))
                            Positioned(
                              right: 5,
                              bottom: 40,
                              child: Icon(
                                Icons.check_circle,
                                size: 35,
                                color: const Color.fromARGB(255, 12, 68, 13),
                              ),
                            )
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        if (selected.contains("Concerts")) {
                          selected.remove("Concerts");
                        } else if (selected.length < 3) {
                          selected.add("Concerts");
                        }
                        setState(() {});
                      },
                      child: Stack(
                        children: [
                          Column(children: [
                            Image.asset("assets/mic.png"),
                            Text(
                              "Concerts",
                              style: TextStyle(fontFamily: "libre"),
                            )
                          ]),
                          if (selected.contains("Concerts"))
                            Positioned(
                              right: 5,
                              bottom: 40,
                              child: Icon(
                                Icons.check_circle,
                                size: 35,
                                color: const Color.fromARGB(255, 12, 68, 13),
                              ),
                            )
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        if (selected.contains("Expositions")) {
                          selected.remove("Expositions");
                        } else if (selected.length < 3) {
                          selected.add("Expositions");
                        }
                        setState(() {});
                      },
                      child: Stack(
                        children: [
                          Column(children: [
                            Image.asset("assets/image.png"),
                            Text(
                              "Expositions",
                              style: TextStyle(fontFamily: "libre"),
                            )
                          ]),
                          if (selected.contains("Expositions"))
                            Positioned(
                              right: 5,
                              bottom: 40,
                              child: Icon(
                                Icons.check_circle,
                                size: 35,
                                color: const Color.fromARGB(255, 12, 68, 13),
                              ),
                            )
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        if (selected.contains("Restraurants")) {
                          selected.remove("Restraurants");
                        } else if (selected.length < 3) {
                          selected.add("Restraurants");
                        }
                        setState(() {});
                      },
                      child: Stack(
                        children: [
                          Column(children: [
                            Image.asset("assets/movie2.png"),
                            Text(
                              "Restraurants",
                              style: TextStyle(fontFamily: "libre"),
                            )
                          ]),
                          if (selected.contains("Restraurants"))
                            Positioned(
                              right: 5,
                              bottom: 40,
                              child: Icon(
                                Icons.check_circle,
                                size: 35,
                                color: const Color.fromARGB(255, 12, 68, 13),
                              ),
                            )
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        if (selected.contains("Spectacles viviants")) {
                          selected.remove("Spectacles viviants");
                        } else if (selected.length < 3) {
                          selected.add("Spectacles viviants");
                        }
                        setState(() {});
                      },
                      child: Stack(
                        children: [
                          Column(children: [
                            Image.asset("assets/movie2.png"),
                            Center(
                              child: Text(
                                "Spectacles\n   viviants",
                                style: TextStyle(fontFamily: "libre"),
                              ),
                            )
                          ]),
                          if (selected.contains("Spectacles viviants"))
                            Positioned(
                              right: 5,
                              bottom: 40,
                              child: Icon(
                                Icons.check_circle,
                                size: 35,
                                color: const Color.fromARGB(255, 12, 68, 13),
                              ),
                            )
                        ],
                      ),
                    )
                  ]),
            ),
            const SizedBox(height: 20),
            MaterialButton(
                minWidth: double.infinity,
                color: Color.fromARGB(255, 191, 130, 132),
                height: 64,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                onPressed: () {
                  if (selected.length < 2) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text("Veuillez choisir au moins 2 options"),
                    ));
                    return;
                  } else {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => BottomScreen()));
                  }
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Démarrons maintenant",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontFamily: "libre",
                          fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                    )
                  ],
                ))
          ],
        ),
      )),
    );
  }
}
