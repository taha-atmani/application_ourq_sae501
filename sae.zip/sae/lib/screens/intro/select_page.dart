import 'package:flutter/material.dart';
import 'package:step_progress_indicator/step_progress_indicator.dart';

import '../bottom_bar/bottom_nav.dart';

class SelectPage extends StatefulWidget {
  const SelectPage({super.key});

  @override
  State<SelectPage> createState() => _SelectPageState();
}

class _SelectPageState extends State<SelectPage> {
  // Liste des types de sorties sélectionnés par l'utilisateur
  List<String> selected = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Indicateur de progression (étape 2 sur 3)
              StepProgressIndicator(
                totalSteps: 3,
                currentStep: 2,
                selectedColor: Color(0xFFDA494F),
                unselectedColor: Colors.grey,
              ),
              const SizedBox(height: 20),
              // Titre de la page
              Text(
                "Choisissez 2 ou 3 types de sorties qui vous intéressent. ",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                  fontFamily: "libre",
                ),
              ),
              const SizedBox(height: 20),

              // Grille des choix de sorties
              Expanded(
                child: GridView(
                  shrinkWrap: true,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    mainAxisExtent: 150,
                  ),
                  children: [
                    // Chaque élément est un GestureDetector qui gère le clic utilisateur
                    _buildChoice("Bars", "assets/beer.png"),
                    _buildChoice("Cinemas", "assets/movie.png"),
                    _buildChoice("Concerts", "assets/mic.png"),
                    _buildChoice("Expositions", "assets/image.png"),
                    _buildChoice("Restraurants", "assets/movie2.png"),
                    _buildChoice("Spectacles viviants", "assets/movie2.png",
                        isMultiline: true),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Bouton pour continuer
              MaterialButton(
                minWidth: double.infinity,
                color: Color.fromARGB(255, 191, 130, 132),
                height: 64,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                onPressed: () {
                  // Vérifie qu'au moins 2 choix ont été sélectionnés
                  if (selected.length < 2) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Veuillez choisir au moins 2 options"),
                      ),
                    );
                    return;
                  }
                  // Passe à la page suivante
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => BottomScreen()),
                  );
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Démarrons maintenant",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontFamily: "libre",
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Icon(Icons.arrow_forward, color: Colors.white),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Widget pour afficher une case sélectionnable avec une image et un texte
  Widget _buildChoice(String label, String assetPath,
      {bool isMultiline = false}) {
    return GestureDetector(
      onTap: () {
        // Ajoute ou retire la sélection selon l'état actuel
        if (selected.contains(label)) {
          selected.remove(label);
        } else if (selected.length < 3) {
          selected.add(label);
        }
        setState(() {});
      },
      child: Stack(
        children: [
          Column(
            children: [
              Image.asset(assetPath),
              isMultiline
                  ? Center(
                      child: Text(
                        label,
                        style: TextStyle(fontFamily: "libre"),
                        textAlign: TextAlign.center,
                      ),
                    )
                  : Text(
                      label,
                      style: TextStyle(fontFamily: "libre"),
                    )
            ],
          ),
          // Icône de validation si l'option est sélectionnée
          if (selected.contains(label))
            Positioned(
              right: 5,
              bottom: 40,
              child: Icon(
                Icons.check_circle,
                size: 35,
                color: const Color.fromARGB(255, 12, 68, 13),
              ),
            )
        ],
      ),
    );
  }
}
