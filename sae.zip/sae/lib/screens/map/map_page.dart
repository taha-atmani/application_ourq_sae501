import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  GoogleMapController? _mapController;
  final Set<Marker> _markers = {};
  BitmapDescriptor? _avatarIcon;

  // Point de départ fixe
  static const LatLng _initialPosition = LatLng(48.8975, 2.4100);

  final LatLngBounds _canalBounds = LatLngBounds(
    southwest: LatLng(48.8850, 2.3650),
    northeast: LatLng(48.9100, 2.4550),
  );

  final double _minZoom = 13.0;
  final double _maxZoom = 18.0;

  @override
  void initState() {
    super.initState();
    _loadCustomMarkers(); // Charge juste les marqueurs fixes
  }

  Future<void> _loadCustomMarkers() async {
    _avatarIcon ??= await BitmapDescriptor.fromAssetImage(
      const ImageConfiguration(size: Size(24, 24)),
      'assets/markers/avatar.png',
    );

    final List<LatLng> markerPositions = [
      LatLng(48.8957, 2.3838),
      LatLng(48.8955, 2.3866),
      LatLng(48.8952, 2.3900),
      LatLng(48.8950, 2.3923),
      LatLng(48.8946, 2.3944),
      LatLng(48.8972, 2.4010),
      LatLng(48.8993, 2.4156),
      LatLng(48.9035, 2.4304),
    ];

    for (int i = 0; i < markerPositions.length; i++) {
      _markers.add(
        Marker(
          markerId: MarkerId('avatar_$i'),
          position: markerPositions[i],
          icon: _avatarIcon!,
          infoWindow: InfoWindow(title: 'Point ${i + 1}'),
          onTap: _showInfoSheet,
        ),
      );
    }

    if (mounted) setState(() {});
  }

  Future<void> _getCurrentLocation() async {
    try {
      final hasPermission = await _handleLocationPermission();
      if (!hasPermission) return;

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.lowest,
      );

      final userLatLng = LatLng(position.latitude, position.longitude);

      setState(() {
        _markers.add(
          Marker(
            markerId: const MarkerId('currentLocation'),
            position: userLatLng,
            infoWindow: const InfoWindow(title: 'Vous êtes ici'),
          ),
        );
      });

      _mapController?.animateCamera(CameraUpdate.newLatLngZoom(userLatLng, 15));
    } catch (e) {
      debugPrint('Erreur localisation: $e');
    }
  }

  Future<bool> _handleLocationPermission() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return false;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    return permission != LocationPermission.denied &&
        permission != LocationPermission.deniedForever;
  }

  void _showInfoSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Galerie Thaddaeus Ropac',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text('69 Avenue du Général Leclerc, 93500 Pantin'),
              const SizedBox(height: 12),
              Row(
                children: [
                  Chip(
                    label: const Text('Exposition'),
                    backgroundColor: Colors.purple[100],
                  ),
                  const SizedBox(width: 8),
                  const Chip(
                    label: Text(
                      'Ouvert',
                      style: TextStyle(color: Colors.white),
                    ),
                    backgroundColor: Colors.green,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.directions),
                    label: const Text('Démarrer'),
                  ),
                  ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.phone),
                    label: const Text('Appeler'),
                  ),
                  ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.web),
                    label: const Text('Site web'),
                  ),
                  IconButton(
                    icon: const Icon(Icons.favorite_border),
                    onPressed: () {},
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: _getCurrentLocation,
        child: const Icon(Icons.my_location),
      ),
      body: SafeArea(
        child: GoogleMap(
          zoomControlsEnabled: false,
          initialCameraPosition: const CameraPosition(
            target: _initialPosition,
            zoom: 14,
          ),
          markers: _markers,
          onMapCreated: (controller) {
            _mapController = controller;
          },
          minMaxZoomPreference: MinMaxZoomPreference(_minZoom, _maxZoom),
          cameraTargetBounds: CameraTargetBounds(_canalBounds),
          zoomGesturesEnabled: true,
          myLocationEnabled: false, // ✅ Économie de data
          myLocationButtonEnabled: false,
          trafficEnabled: false,
          buildingsEnabled: false,
          indoorViewEnabled: false,
          compassEnabled: false,
          mapToolbarEnabled: false,
        ),
      ),
    );
  }
}
