import 'package:flutter/material.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';
import 'package:sae/screens/barcode/barcode_page.dart';
import 'package:sae/screens/calendar/calendar_page.dart';
import 'package:sae/screens/home/home.dart';
import 'package:sae/screens/map/map_page.dart';
import 'package:sae/screens/profile/profile_page.dart';

class BottomScreen extends StatefulWidget {
  const BottomScreen({super.key});

  @override
  State<BottomScreen> createState() => _BottomScreenState();
}

class _BottomScreenState extends State<BottomScreen> {
  late PersistentTabController _controller;
  @override
  void initState() {
    _controller = PersistentTabController(initialIndex: 0);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PersistentTabView(context, screens: [
      HomeScreen(),
      CalendarPage(),
      MapPage(),
      BarcodePage(),
      ProfilePage()
    ], items: [
      PersistentBottomNavBarItem(
          icon: Icon(Icons.home),
          title: "",
          activeColorPrimary: Color(0xFFDA494F),
          inactiveColorPrimary: Colors.grey),
      PersistentBottomNavBarItem(
          icon: Icon(Icons.calendar_month),
          title: "",
          activeColorPrimary: Color(0xFFDA494F),
          inactiveColorPrimary: Colors.grey),
      PersistentBottomNavBarItem(
          icon: Icon(Icons.map_outlined),
          title: "",
          activeColorPrimary: Color(0xFFDA494F),
          inactiveColorPrimary: Colors.grey),
      PersistentBottomNavBarItem(
          icon: Icon(Icons.qr_code_scanner),
          title: "",
          activeColorPrimary: Color(0xFFDA494F),
          inactiveColorPrimary: Colors.grey),
      PersistentBottomNavBarItem(
          icon: Icon(Icons.person),
          title: "",
          activeColorPrimary: Color(0xFFDA494F),
          inactiveColorPrimary: Colors.grey),
    ]);
  }
}
