// Importation des bibliothèques nécessaires : Flutter, PersistentBottomNavBar, et les pages de l'application
import 'package:flutter/material.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';
import 'package:sae/screens/barcode/barcode_page.dart';
import 'package:sae/screens/calendar/calendar_page.dart';
import 'package:sae/screens/home/home.dart';
import 'package:sae/screens/map/map_page.dart';
import 'package:sae/screens/profile/profile_page.dart';

// Définition de la classe BottomScreen qui est un StatefulWidget
class BottomScreen extends StatefulWidget {
  const BottomScreen({super.key}); // Constructeur de la classe

  @override
  State<BottomScreen> createState() =>
      _BottomScreenState(); // Crée l'état associé à ce widget
}

// État de la classe BottomScreen
class _BottomScreenState extends State<BottomScreen> {
  // Déclaration d'un contrôleur pour gérer la navigation entre les onglets du Bottom Navigation
  late PersistentTabController _controller;

  @override
  void initState() {
    super.initState();
    // Initialisation du contrôleur avec l'index initial de l'onglet (ici, l'index 0)
    _controller = PersistentTabController(initialIndex: 0);
  }

  @override
  Widget build(BuildContext context) {
    // Retourne le widget PersistentTabView qui permet de gérer un Bottom Navigation persistant
    return PersistentTabView(
      context,
      // Liste des écrans à afficher pour chaque onglet
      screens: [
        HomeScreen(), // Écran d'accueil
        CalendarPage(), // Écran de calendrier
        MapPage(), // Écran de carte
        BarcodePage(), // Écran de scan de code-barres
        ProfilePage() // Écran de profil
      ],
      // Liste des éléments (onglets) dans la barre de navigation inférieure
      items: [
        PersistentBottomNavBarItem(
            icon: Icon(Icons.home), // Icône pour l'onglet "Accueil"
            title: "", // Pas de titre sous l'icône
            activeColorPrimary: Color(0xFFDA494F), // Couleur active de l'icône
            inactiveColorPrimary: Colors.grey // Couleur inactive de l'icône
            ),
        PersistentBottomNavBarItem(
            icon:
                Icon(Icons.calendar_month), // Icône pour l'onglet "Calendrier"
            title: "",
            activeColorPrimary: Color(0xFFDA494F),
            inactiveColorPrimary: Colors.grey),
        PersistentBottomNavBarItem(
            icon: Icon(Icons.map_outlined), // Icône pour l'onglet "Carte"
            title: "",
            activeColorPrimary: Color(0xFFDA494F),
            inactiveColorPrimary: Colors.grey),
        PersistentBottomNavBarItem(
            icon: Icon(Icons
                .qr_code_scanner), // Icône pour l'onglet "Scan de code-barres"
            title: "",
            activeColorPrimary: Color(0xFFDA494F),
            inactiveColorPrimary: Colors.grey),
        PersistentBottomNavBarItem(
            icon: Icon(Icons.person), // Icône pour l'onglet "Profil"
            title: "",
            activeColorPrimary: Color(0xFFDA494F),
            inactiveColorPrimary: Colors.grey),
      ],
      controller:
          _controller, // Utilisation du contrôleur pour gérer la sélection des onglets
    );
  }
}
