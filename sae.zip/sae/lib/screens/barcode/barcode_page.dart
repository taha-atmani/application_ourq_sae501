// Importation de la bibliothèque Flutter Material
import 'package:flutter/material.dart';

// Définition d'un widget Stateless pour la page du scanner de code-barres
class BarcodePage extends StatelessWidget {
  const BarcodePage(
      {super.key}); // Constructeur de la classe BarcodePage avec une clé pour le widget

  @override
  Widget build(BuildContext context) {
    // Construction du widget Scaffold qui fournit la structure de base pour l'interface
    return Scaffold(
      body: SafeArea(
        // SafeArea pour s'assurer que le contenu ne soit pas recouvert par des éléments système (barre de statut, encoche, etc.)
        child: Image.asset(
          // Affichage d'une image à partir des assets de l'application
          "assets/Scanner.png", // Chemin de l'image à afficher
          fit: BoxFit
              .cover, // Le mode BoxFit.cover permet à l'image de couvrir toute la zone disponible tout en gardant ses proportions
          height: double
              .infinity, // Hauteur de l'image égale à la hauteur maximale disponible
        ),
      ),
    );
  }
}
