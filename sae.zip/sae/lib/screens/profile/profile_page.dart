import 'package:flutter/material.dart';
// Importation de la bibliothèque Material Design de Flutter.

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  // Page de profil définie comme un widget sans état.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        // Permet d'éviter les zones sensibles (encoches, etc.)
        child: SingleChildScrollView(
          // Rend la page scrollable si le contenu dépasse l'écran
          child: Padding(
            padding: const EdgeInsets.all(
                8.0), // Ajoute un peu d'espace autour du contenu
            child: Column(
              children: [
                // En-tête avec logo et icône de notification
                Row(
                  children: [
                    Image.asset("assets/logoOurcq'éo.png"),
                    const Spacer(), // Espace flexible pour pousser l'icône à droite
                    Image.asset("assets/iconenotification.png")
                  ],
                ),
                const SizedBox(height: 10), // Espacement vertical

                // Avatar de l'utilisateur
                Image.asset("assets/avatar.png"),
                const SizedBox(height: 10),

                // Nom de l'utilisateur
                const Text(
                  "Gauthier m .",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),

                // Carte utilisateur
                Image.asset("assets/carteOurcquéo.png"),
                const SizedBox(height: 10),

                // Barre de progression
                Image.asset("assets/barreprogression.png"),
                const SizedBox(height: 20),

                // Titre "Succès" avec un lien vers tous les succès
                Row(
                  children: [
                    const Text(
                      "Succès",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      "Afficher \ntout",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueAccent,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                // Image illustrant les succès récents
                Image.asset("assets/Frame 33749.png"),
                const SizedBox(height: 20),

                // Section personnalisée codée manuellement (remplaçant potentiellement une image statique)
                _buildProfileSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Méthode pour construire les sections "Votre activité" et "À propos de vous"
  Widget _buildProfileSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Votre activité",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),

        // Liste des options liées à l'activité de l'utilisateur
        _buildMenuItem(Icons.emoji_events, "récompenses"),
        _buildMenuItem(Icons.favorite, "Mes favoris"),
        _buildMenuItem(Icons.history, "Mon historique"),

        const SizedBox(height: 20),

        const Text(
          "À propos de vous",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),

        // Informations personnelles et paramètres
        _buildMenuItem(Icons.person, "Informations personnelles"),
        _buildMenuItem(Icons.settings, "Paramètres"),
      ],
    );
  }

  // Méthode pour construire chaque item de menu avec une icône, un titre et une flèche
  Widget _buildMenuItem(IconData icon, String title) {
    return ListTile(
      leading: Icon(icon, color: Colors.black), // Icône à gauche
      title: Text(title, style: const TextStyle(fontSize: 16)), // Titre
      trailing:
          const Icon(Icons.arrow_forward_ios, size: 16), // Flèche à droite
      onTap: () {
        // À compléter : action lors du clic sur l’élément
      },
    );
  }
}
