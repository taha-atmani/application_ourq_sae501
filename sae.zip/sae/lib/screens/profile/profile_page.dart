import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              // En-tête
              Row(
                children: [
                  Image.asset("assets/logoOurcq'éo.png"),
                  const Spacer(),
                  Image.asset("assets/iconenotification.png")
                ],
              ),
              const SizedBox(height: 10),
              Image.asset("assets/avatar.png"),
              const SizedBox(height: 10),
              const Text("Gauthier m .",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Image.asset("assets/carteOurcquéo.png"),
              const SizedBox(height: 10),
              Image.asset("assets/barreprogression.png"),
              const SizedBox(height: 20),

              // Section "Success"
              Row(
                children: [
                  const Text("Succès",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      )),
                  const Spacer(),
                  Text("Afficher \ntout",
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.blueAccent)),
                ],
              ),
              const SizedBox(height: 10),
              Image.asset("assets/Frame 33749.png"),
              const SizedBox(height: 20),

              // Section codée (remplace l'image actuelle)
              _buildProfileSection(),
            ],
          ),
        ),
      )),
    );
  }

  Widget _buildProfileSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Votre activité",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        _buildMenuItem(Icons.emoji_events, "récompenses"),
        _buildMenuItem(Icons.favorite, "Mes favoris"),
        _buildMenuItem(Icons.history, "Mon historique"),
        const SizedBox(height: 20),
        const Text("À propos de vous",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        _buildMenuItem(Icons.person, "Informations personnelles"),
        _buildMenuItem(Icons.settings, "Paramètres"),
      ],
    );
  }

  Widget _buildMenuItem(IconData icon, String title) {
    return ListTile(
      leading: Icon(icon, color: Colors.black),
      title: Text(title, style: const TextStyle(fontSize: 16)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: () {
        // Ajoute ici l'action lorsqu'on clique sur un bouton
      },
    );
  }
}
