// Importation des bibliothèques nécessaires
import 'package:flutter/material.dart'; // Bibliothèque Flutter Material pour l'UI
import 'package:table_calendar/table_calendar.dart'; // Bibliothèque pour afficher un calendrier interactif

// Définition d'un widget Stateful pour la page du calendrier
class CalendarPage extends StatefulWidget {
  const CalendarPage(
      {super.key}); // Constructeur de la page avec une clé pour le widget

  @override
  State<CalendarPage> createState() =>
      _CalendarPageState(); // Création de l'état pour ce widget
}

// Définition de l'état pour le widget CalendarPage
class _CalendarPageState extends State<CalendarPage> {
  // Liste des images à afficher sous le calendrier
  List img = [
    "assets/suggestion1.png",
    "assets/suggestion2.png",
    "assets/suggestion3.png",
    "assets/suggestion4.png"
  ];

  // Variable pour stocker le jour sélectionné, initialisée à la date actuelle
  DateTime selectedDay = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Structure de base de la page avec Scaffold
      body: SafeArea(
        // SafeArea pour s'assurer que les widgets ne sont pas recouverts par la barre de statut ou l'encoche
        child: Column(
          // Disposition des éléments en colonne
          spacing: 15, // Espacement entre les éléments dans la colonne
          children: [
            // TableCalendar pour afficher un calendrier interactif
            TableCalendar(
              calendarFormat: CalendarFormat
                  .week, // Le format du calendrier est sur une seule semaine
              focusedDay: selectedDay, // Jour actuellement sélectionné
              currentDay: selectedDay, // Jour actuel
              firstDay: DateTime
                  .now(), // Premier jour du calendrier (ici, aujourd'hui)
              rangeStartDay:
                  DateTime.now(), // Début de la plage de dates (aujourd'hui)
              lastDay: DateTime.now().add(const Duration(
                  days:
                      20)), // Fin de la plage de dates (20 jours après aujourd'hui)
              onDaySelected: (selectedDay, focusedDay) {
                // Callback pour le jour sélectionné
                print(
                    focusedDay); // Affichage du jour sélectionné dans la console
                setState(() {
                  // Mise à jour de l'état pour redessiner l'interface avec le jour sélectionné
                  this.selectedDay = selectedDay;
                });
              },
            ),
            // Liste des images à afficher en dessous du calendrier
            Expanded(
              // Utilisation de Expanded pour remplir l'espace restant
              child: ListView.separated(
                // ListView pour afficher une liste d'éléments séparés
                shrinkWrap:
                    true, // Permet à la liste de s'ajuster à la taille de son contenu
                itemCount:
                    img.length, // Nombre d'éléments dans la liste d'images
                separatorBuilder: (context, index) =>
                    const SizedBox(), // Aucun séparateur entre les éléments (vide)
                itemBuilder: (context, index) => Image.asset(img[
                    index]), // Construction de chaque élément avec une image
              ),
            )
          ],
        ),
      ),
    );
  }
}
