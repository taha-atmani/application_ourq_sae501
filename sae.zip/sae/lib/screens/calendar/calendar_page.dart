import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class CalendarPage extends StatefulWidget {
  const CalendarPage({super.key});

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  List img = [
    "assets/suggestion1.png",
    "assets/suggestion2.png",
    "assets/suggestion3.png",
    "assets/suggestion4.png"
  ];
  DateTime selectedDay = DateTime.now();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Column(
        spacing: 15,
        children: [
          TableCalendar(
            calendarFormat: CalendarFormat.week,
            focusedDay: selectedDay,
            currentDay: selectedDay,
            firstDay: DateTime.now(),
            rangeStartDay: DateTime.now(),
            lastDay: DateTime.now().add(const Duration(days: 20)),
            onDaySelected: (selectedDay, focusedDay) {
              print(focusedDay);
              setState(() {
                this.selectedDay = selectedDay;
              });
            },
          ),
          Expanded(
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: img.length,
              separatorBuilder: (context, index) => const SizedBox(),
              itemBuilder: (context, index) => Image.asset(img[index]),
            ),
          )
        ],
      )),
    );
  }
}
