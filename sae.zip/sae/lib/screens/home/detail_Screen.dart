// Importation de la bibliothèque Flutter Material
import 'package:flutter/material.dart';

// Déclaration d'un widget Stateless pour l'écran de détails
class DetailScreen extends StatelessWidget {
  const DetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Construction de l'écran à l'aide d'un Scaffold pour gérer la structure de la page
    return Scaffold(
      // Utilisation de SafeArea pour s'assurer que les widgets ne sont pas cachés sous les zones de l'écran
      body: SafeArea(
        child: SingleChildScrollView(
          // Permet de rendre l'écran défilable si le contenu dépasse la taille de l'écran
          child: Padding(
            padding: const EdgeInsets.all(
                8.0), // Ajout de marges autour du contenu pour un espacement agréable
            child: Column(
              // Utilisation d'une colonne pour organiser verticalement les widgets
              spacing: 15, // Espacement entre les éléments de la colonne
              crossAxisAlignment:
                  CrossAxisAlignment.start, // Alignement des éléments à gauche
              children: [
                // Affichage du logo de l'événement
                Image.asset("assets/logoOurcq'éo.png"),

                // Barre de navigation pour revenir à l'écran précédent
                Row(
                  children: [
                    GestureDetector(
                        onTap: () {
                          // Action de retour au précédent écran lorsque l'icône est tapée
                          Navigator.pop(context);
                        },
                        child: Icon(Icons.arrow_back)), // Icône de retour
                    Text(
                      "Retour", // Texte pour le bouton de retour
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w400,
                        color: Colors.black54,
                      ),
                    )
                  ],
                ),

                // Affichage de l'image principale de l'événement
                Image.asset(
                  "assets/image33.png",
                  width:
                      double.infinity, // Largeur de l'image à 100% de l'écran
                  fit: BoxFit
                      .cover, // Remplissage de l'image pour couvrir la largeur
                ),

                // Titre de l'exposition avec un style personnalisé
                Text('Exposition “ L’art américain dans les années 70',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: Colors.black,
                      fontFamily: "libre",
                    )),

                // Localisation de l'événement avec une icône pour la position
                Row(
                  children: [
                    Icon(Icons.location_on_sharp, color: Color(0xff313165)),
                    Text(
                      "Galerie Thaddaeus Ropac", // Texte de la localisation
                      style: TextStyle(color: Color(0xff313165), fontSize: 18),
                    )
                  ],
                ),

                // Badge de type d'événement
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18), // Coins arrondis
                    color: Color(0xff313165), // Couleur de fond
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "Exposition", // Texte à l'intérieur du badge
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),

                // Titre des informations sur l'événement
                Text("Informations sur l’évènement :",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Colors.black,
                      fontFamily: "libre",
                    )),

                // Description détaillée de l'événement
                Text(
                  'Plongez dans une décennie révolutionnaire pour l’art contemporain...',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: Colors.black54,
                    fontFamily: "libre",
                  ),
                ),

                // Image illustrative supplémentaire
                Image.asset(
                  "assets/toutes.png",
                  width:
                      double.infinity, // Largeur de l'image à 100% de l'écran
                  fit: BoxFit.fitWidth, // L'image s'ajuste à la largeur
                ),

                // Bouton permettant d'accéder au lieu de l'événement
                Center(
                    child: MaterialButton(
                        color: Color(0xFFDA494F), // Couleur du bouton
                        height: 54, // Hauteur du bouton
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              10), // Coins arrondis du bouton
                        ),
                        onPressed: () {}, // Action au clic du bouton
                        child: Text(
                          "Accéder au lieu", // Texte du bouton
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontFamily: "libre",
                              fontWeight: FontWeight.w500),
                        ))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
