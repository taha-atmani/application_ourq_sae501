import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  const DetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              spacing: 15,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset("assets/logoOurcq'éo.png"),
                Row(
                  children: [
                    GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(Icons.arrow_back)),
                    Text(
                      "Retour",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w400,
                        color: Colors.black54,
                      ),
                    )
                  ],
                ),
                Image.asset(
                  "assets/image33.png",
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
                Text('Exposition “ L’art américain dans les années 70',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: Colors.black,
                      fontFamily: "libre",
                    )),
                Row(
                  children: [
                    Icon(Icons.location_on_sharp, color: Color(0xff313165)),
                    Text(
                      "Galerie Thaddaeus Ropac",
                      style: TextStyle(color: Color(0xff313165), fontSize: 18),
                    )
                  ],
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    color: Color(0xff313165),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "Exposition",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
                Text("Informations sur l’évènement :",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Colors.black,
                      fontFamily: "libre",
                    )),
                Text(
                  'Plongez dans une décennie révolutionnaire pour l’art contemporain avec l’exposition “L’art américain dans les années 70”, présentée à la prestigieuse Galerie Thaddaeus Ropac.Découvrez une collection exceptionnelle d’œuvres marquantes, où des artistes tels qu’Andy Warhol, Cindy Sherman, et Richard Serra réinventent l’art à travers le pop art, le minimalisme et l’art conceptuel.Cette exposition explore les tensions sociales et politiques de ’époque, tout en mettant en avant l’effervescence créative qui a propulsé l’art américain sur la scène internationale. Entre peintures, sculptures, photographies et installations immersives, laissez-vous captiver par l’esprit visionnaire des années 70.',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: Colors.black54,
                    fontFamily: "libre",
                  ),
                ),
                Image.asset(
                  "assets/toutes.png",
                  width: double.infinity,
                  fit: BoxFit.fitWidth,
                ),
                Center(
                  child: MaterialButton(
                      color: Color(0xFFDA494F),
                      height: 54,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      onPressed: () {},
                      child: Text(
                        "Accéder au lieu",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontFamily: "libre",
                            fontWeight: FontWeight.w500),
                      )),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
